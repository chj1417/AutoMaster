#!/bin/sh
cd `dirname $0`
cd ../../..
./bin/main $@
